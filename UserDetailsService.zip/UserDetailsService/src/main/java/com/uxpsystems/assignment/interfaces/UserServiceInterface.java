package com.uxpsystems.assignment.interfaces;

import com.uxpsystems.assignment.entity.UserDetailsResponse;
import com.uxpsystems.assignment.entity.UserEntity;

public interface UserServiceInterface {

	UserDetailsResponse getUserDetails(Long userId) throws Exception;

	UserDetailsResponse saveUserDetails(UserEntity userEntity) throws Exception;

	String deleteUser(Long userId) throws Exception;

	UserDetailsResponse saveAndUpdateUserDetails(UserEntity userEntity) throws Exception;
}