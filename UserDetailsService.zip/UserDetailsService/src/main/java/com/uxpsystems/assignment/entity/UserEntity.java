package com.uxpsystems.assignment.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "User_Table")
public class UserEntity {

	@Id
	private Long id;
	private String userName;
	private char[] password;
	private String status;

	public boolean isValid() {
		return null != this.id && null != this.userName && null != this.password && null != this.status;
	}
}