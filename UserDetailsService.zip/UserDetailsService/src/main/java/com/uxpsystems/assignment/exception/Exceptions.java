package com.uxpsystems.assignment.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Exceptions {

	private int errorCode;
	private String errorMessage;
}
