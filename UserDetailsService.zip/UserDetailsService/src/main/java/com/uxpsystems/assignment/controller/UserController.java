package com.uxpsystems.assignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uxpsystems.assignment.entity.UserDetailsResponse;
import com.uxpsystems.assignment.entity.UserEntity;
import com.uxpsystems.assignment.interfaces.UserServiceInterface;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserServiceInterface userService;

	@GetMapping("/{userId}")
	public ResponseEntity<UserDetailsResponse> getUser(@PathVariable Long userId) throws Exception {
		return new ResponseEntity<UserDetailsResponse>(userService.getUserDetails(userId), HttpStatus.OK);
	}

	@PostMapping()
	public ResponseEntity<UserDetailsResponse> createUser(@RequestBody UserEntity userEntity) throws Exception {
		return new ResponseEntity<UserDetailsResponse>(userService.saveUserDetails(userEntity), HttpStatus.OK);
	}

	@PutMapping()
	public ResponseEntity<UserDetailsResponse> updateUser(@RequestBody UserEntity userEntity) throws Exception {
		return new ResponseEntity<UserDetailsResponse>(userService.saveAndUpdateUserDetails(userEntity), HttpStatus.OK);
	}

	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable Long userId) throws Exception {
		return new ResponseEntity<String>(userService.deleteUser(userId), HttpStatus.OK);
	}
}