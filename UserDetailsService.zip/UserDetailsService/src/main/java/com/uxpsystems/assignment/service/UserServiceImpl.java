package com.uxpsystems.assignment.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.uxpsystems.assignment.entity.UserDetailsResponse;
import com.uxpsystems.assignment.entity.UserEntity;
import com.uxpsystems.assignment.interfaces.UserServiceInterface;
import com.uxpsystems.assignment.repository.UserRepository;

@Service
public class UserServiceImpl implements UserServiceInterface {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public UserDetailsResponse getUserDetails(Long userId) throws Exception {

		if (null != userId) {
			Optional<UserEntity> findById = userRepository.findById(userId);
			if (findById.isPresent()) {
				return new UserDetailsResponse(findById.get());
			} else {
				throw new Exception("User Not Available");
			}
		} else {
			throw new Exception("Invalid User Id");
		}
	}

	public UserDetailsResponse saveAndUpdateUserDetails(UserEntity userEntity) throws Exception {
		if (userEntity.isValid()) {
			userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword().toString()).toCharArray());
			UserEntity savedUser = userRepository.save(userEntity);
			return new UserDetailsResponse(savedUser);
		} else {
			throw new Exception("Invalid Request. Null values is not accepted");
		}
	}

	public String deleteUser(Long userId) throws Exception {
		if (Optional.ofNullable(getUserDetails(userId)).isPresent()) {
			userRepository.deleteById(userId);
			return "User Deleted";
		} else {
			throw new Exception("User not available");
		}
	}

	public UserDetailsResponse saveUserDetails(UserEntity userEntity) throws Exception {
		if (userEntity.isValid()) {
			if (!userRepository.findByIdOrUserName(userEntity.getId(), userEntity.getUserName()).isPresent()) {
				userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword().toString()).toCharArray());
				UserEntity savedUser = userRepository.save(userEntity);
				return new UserDetailsResponse(savedUser);
			} else {
				throw new Exception("User is already Available");
			}
		} else {
			throw new Exception("Invalid Request. Null values is not accepted");
		}
	}
}