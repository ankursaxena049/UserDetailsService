package com.uxpsystems.assignment.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uxpsystems.assignment.entity.UserEntity;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Number> {

	public Optional<UserEntity> findByIdOrUserName(Long id, String name);
}